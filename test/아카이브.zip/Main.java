import bin.apply.Repository;
import bin.apply.start.Bracket;

import java.io.*;
import java.util.HashMap;
import java.util.ListIterator;
import java.util.Map;

import static java.nio.charset.StandardCharsets.*;

public class Main {
    public static void main(String[] args) {
//        CalculatorToken token = new CalculatorToken();
//        System.out.println(token.getTokens("ㅇㄴㅇㅇㄸㄴㄴㄲ 10ㅇ>ㅇ1 ㄸ 변수1 ㅇ<=ㅇ 100 ㄲ ㅇㄴ ㅇㅇ"));

//        Object file = new File("build.gradle");
//        Method method;
//        try {
//            method = file.getClass().getMethod("isFile");
//            System.out.println(method.invoke(file));
//        } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
//            throw new RuntimeException(e);
//        }
        new Main();
    }

    private Main() {
        String fileName = "build.gradle";
        readFile(fileName);

        Map<Long, String> map = Repository.filesValue.get(fileName);
        map.forEach((k, v) -> {
            if (v.endsWith("{")) {
                long i = new Bracket().getPair(map, k+1);
                System.out.println(i);
                System.out.println(map.get(i));
            }
        });
    }

    private void readFile(String fileName) {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName, UTF_8))) {
            Map<Long, String> map = new HashMap<>();
            ListIterator<String> iterator = reader.lines()
                    .map(String::strip)
                    .toList()
                    .listIterator();
            while (iterator.hasNext()) map.put(iterator.nextIndex() + 1L, iterator.next());
            Repository.filesValue.put(fileName, map);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        System.out.println(Repository.filesValue);
    }
}
