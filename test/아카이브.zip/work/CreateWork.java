package work;

import bin.apply.repository.AccessMap;
import bin.exception.VariableException;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serial;
import java.io.Serializable;

@Getter
@RequiredArgsConstructor
public abstract class CreateWork implements Serializable {
    private final int count;

    protected abstract Object create(Object[] params, AccessMap accessMap);
    protected abstract void reset(ObjectInputStream ois);

    public Object run(Object[] params, AccessMap accessMap) {
        if (params.length != count) throw new VariableException().methodParamsError();
        return create(params, accessMap);
    }

    @Serial
    private void readObject(ObjectInputStream ois) {
        try {
            ois.defaultReadObject();
            reset(ois);
        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}
