package work;

import java.io.Serializable;

public abstract class ReplaceWork implements Serializable {
    public abstract Object start(String line);
}
