package work;

import java.io.Serializable;

public abstract class StartWork implements Serializable {
    public abstract void start(String line, String loop);
}
