package work;

import bin.apply.Repository;
import bin.apply.repository.AccessList;
import bin.exception.FileException;
import bin.exception.MatchException;
import bin.exception.VariableException;
import lombok.Getter;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serial;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;

@Getter
public abstract class CreateWork<T> implements Serializable {
    private final Class<T> klass;
    private final String klassName;
    private final String[] params;

    public CreateWork(Class<T> klass, String klassName, String...params) {
        this.klass = klass;
        this.klassName = klassName;
        this.params = params;
        // 이미 정의된 타입일때
        if (Repository.createWork.containsKey(klassName))
            throw VariableException.DEFINE_TYPE.getThrow(klassName);
        // 존재하지 않는 타입일때 (자기 자신 클래스 허용)
        for (String param : params) {
            if (!(Repository.createWork.containsKey(param) || param.equals(klassName)))
                throw VariableException.NO_DEFINE_TYPE.getThrow(param);
        }
        resetItem();
    }

    protected abstract Object createItem(AccessList repositoryArray, String... params);
    protected abstract void reset();

    public boolean check(Object value) {
        return klass.equals(value.getClass());
    }

    public Object cast(AccessList repositoryArray, String...params) {
        int count = params.length;
        // 파라미터 갯수 확인
        if (count != this.params.length) {
            String errorMessage = klassName.concat(" ").concat(String.join(", ", this.params));
            throw MatchException.PARAM_COUNT_ERROR.getThrow(errorMessage);
        }
        // 타입 확인
        Object[] paramValues = new Object[count];
        for (int i = 0; i < count; i++) {
            String type = this.params[i];
            String value = params[i];
            Object v;

            if (klass.equals(String.class)) v = value;
            else if (repositoryArray.find(value)) v = repositoryArray.get(value);
            else v = Repository.createWork.get(type).create(repositoryArray, value);
            /**
             * @TODO 변수명이 아닐때 동작 해결, 메소드 반환 해결
             */

            if (!Repository.createWork.get(type).check(v)) {
                String errorMessage = "type: ".concat(type).concat(", value: ").concat(value);
                throw VariableException.DEFINE_TYPE.getThrow(errorMessage);
            }
            paramValues[i] = v;
        }

        return paramValues;
    }

    public Object create(AccessList repositoryArray, String...params) {
        int count = params.length;
        // 파라미터 갯수 확인
        if (count != this.params.length) {
            String errorMessage = klassName.concat(" ").concat(String.join(", ", this.params));
            throw MatchException.PARAM_COUNT_ERROR.getThrow(errorMessage);
        }
        return createItem(repositoryArray, params);
    }

    public int getParamsCount() {
        return params.length;
    }

    @Serial
    private void readObject(ObjectInputStream ois) {
        try {
            ois.defaultReadObject();
            resetItem();
        } catch (IOException | ClassNotFoundException e) {
            throw FileException.DO_NOT_INCLUDE.getThrow(e.getMessage());
        }
    }

    /**
     * 클래스를 생성하는 로직
     * @param paramsItem 파라미터 아이템
     * @return 생성된 클래스 반환
     */
    public Object createInstance(Object...paramsItem) {
        // 파라미터 갯수 확인
        if (getParamsCount() != paramsItem.length) {
            String errorMessage = klassName.concat(" ").concat(String.join(", ", this.params));
            throw MatchException.PARAM_COUNT_ERROR.getThrow(errorMessage);
        }

        Class<?>[] klassList = Arrays.stream(this.params)
                .map(Repository.createWork::get)
                .map(CreateWork::getKlass)
                .toList()
                .toArray(new Class<?>[0]);
        try {
            return klass.getConstructor(klassList).newInstance(paramsItem);
        } catch (NoSuchMethodException e) {
            throw MatchException.PARAM_MATCH_ERROR.getThrow(Arrays.toString(this.params));
        } catch (InvocationTargetException | InstantiationException | IllegalAccessException e) {
            String errorMessage = klassName.concat(" ").concat(Arrays.toString(this.params));
            throw VariableException.CREATE_KLASS_ERROR.getThrow(errorMessage);
        }
    }
}
