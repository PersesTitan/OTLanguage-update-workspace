package work;

import bin.apply.item.ParamItem;
import bin.apply.repository.AccessList;
import bin.exception.MatchException;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serial;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Map;

public abstract class ReplaceWork implements Serializable {
    private final ParamItem[] paramItems;

    public ReplaceWork(ParamItem...paramItems) {
        this.paramItems = paramItems;
        reset();
    }

    public abstract Object start(long line, Object[] params, Map<Long, String> repository, AccessList accessList);
    protected abstract void reset();

    @Serial
    private void readObject(ObjectInputStream ois) {
        try {
            ois.defaultReadObject();
            reset();
        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    private Object[] casting(String...values) {
        if (paramItems == null) {
            if (values == null) return null;
            else throw MatchException.PARAM_COUNT_ERROR.getThrow(Arrays.toString(values));
        } else if (paramItems.length == values.length) {
            Object[] params = new Object[values.length];
            for (int i = 0; i<params.length; i++) params[i] = paramItems[i].casting(values[i]);
            return params;
        } else throw MatchException.PARAM_COUNT_ERROR.getThrow(Arrays.toString(values));
    }
}
