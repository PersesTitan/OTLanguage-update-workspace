package work;

import bin.apply.Repository;
import bin.apply.repository.AccessList;
import bin.exception.MatchException;
import bin.exception.VariableException;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serial;
import java.io.Serializable;
import java.util.Map;

public abstract class StartWork implements Serializable {
    private final boolean isLoop;
    private final String[] paramItems;

    public StartWork(boolean isLoop, String... paramItems) {
        for (String paramItem : paramItems) {
            if (!Repository.isClass(paramItem))
                throw VariableException.NO_DEFINE_TYPE.getThrow(paramItem);
        }
        this.paramItems = paramItems;
        this.isLoop = isLoop;
        reset();
    }

    public StartWork(String... paramItems) {
        this(false, paramItems);
    }

    public abstract void start(long line, Object[] params, Map<Long, String> repository, AccessList accessList);
    protected abstract void reset();

    @Serial
    private void readObject(ObjectInputStream ois) {
        try {
            ois.defaultReadObject();
            reset();
        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    public Object[] casting(String line, boolean isLoop, String...values) {
        if (this.isLoop == isLoop) return casting(values);
        else throw MatchException.ZONE_MATCH_ERROR.getThrow(line);
    }

    private Object[] casting(String...values) {
        int count = values.length;
        for (int i = 0; i<count; i++) {
            CreateWork<?> createWork = Repository.createWork.get(paramItems[i]);
//            createWork.
            /**
             * @TODO
             */
        }
        return null;
    }
}
